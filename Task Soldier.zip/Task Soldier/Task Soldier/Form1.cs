﻿using System;
using System.Diagnostics;
using System.Windows.Forms;

namespace Task_Soldier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeDataGridView();
            RefreshProcessList();
        }

        private void InitializeDataGridView()
        {
            // Clear any existing columns
            dataGridView1.Columns.Clear();

            // Add columns for Process ID, Name, and Memory Usage
            dataGridView1.Columns.Add("ProcessID", "Process ID");
            dataGridView1.Columns.Add("ProcessName", "Process Name");
            dataGridView1.Columns.Add("MemoryUsage", "Memory Usage (KB)");

            // Optionally set the column widths
            dataGridView1.Columns[0].Width = 100;
            dataGridView1.Columns[1].Width = 200;
            dataGridView1.Columns[2].Width = 150;

            // Set selection mode to full row select
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false; // Prevent multiple rows from being selected
        }

        private void RefreshProcessList()
        {
            // Clear the DataGridView before adding new data
            dataGridView1.Rows.Clear();

            // Get all running processes
            Process[] processes = Process.GetProcesses();

            // Loop through each process and add its details to the DataGridView
            foreach (Process process in processes)
            {
                try
                {
                    // Add process details to the DataGridView
                    dataGridView1.Rows.Add(
                        process.Id,                    // Process ID
                        process.ProcessName,            // Process Name
                        process.WorkingSet64 / 1024     // Memory usage in KB
                    );
                }
                catch (Exception ex)
                {
                    // Handle cases where process info is inaccessible
                    Console.WriteLine($"Failed to access process: {process.ProcessName} - {ex.Message}");
                }
            }
        }


        // Button to kill the selected process
       
        private void button3_Click(object sender, EventArgs e)
        {
            RefreshProcessList();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                // Get the selected process ID from the DataGridView
                int processId = (int)dataGridView1.SelectedRows[0].Cells[0].Value;

                try
                {
                    // Get the process by ID and kill it
                    Process process = Process.GetProcessById(processId);
                    process.Kill();
                    MessageBox.Show($"Process {process.ProcessName} (ID: {processId}) has been terminated.");
                    RefreshProcessList();  // Refresh list after killing the process
                }
                catch (System.ComponentModel.Win32Exception win32Ex)
                {
                    MessageBox.Show($"Failed to terminate process: Access Denied ({win32Ex.Message})");
                }
                catch (InvalidOperationException invOpEx)
                {
                    MessageBox.Show($"Process has already exited or cannot be accessed: {invOpEx.Message}");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Failed to terminate process: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("Please select a process to kill.");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Process[] processes = Process.GetProcesses(); // Get all the processes in your system

            foreach (var process in processes)
            {
                try
                {
                    // Skip critical system processes to avoid system instability
                    if (process.ProcessName != "explorer" && process.ProcessName != "winlogon" && process.ProcessName != "csrss" && process.ProcessName != "services" && process.ProcessName != "lsass" && process.ProcessName != "System" && process.ProcessName != "Idle" && process.ProcessName != "Task Soldier.exe")
                    {
                        process.Kill(); // Kill the process
                    }
                }
                catch (Exception)
                {
                    // Silently handle exceptions to avoid disrupting the user experience
                }
            }
        }
    }
    
}
